#include "FreeRTOS/FreeRTOS.h"
#include "FreeRTOS/task.h"
#include "FreeRTOS/queue.h"
#include "FreeRTOS/semphr.h"
#include "shared_state.h"

/* Created in main.c */
extern QueueHandle_t rocofQueue;

void ROCOFTask(void *pvParameters)
{
    float currentFrequencyHz;
    float lastFrequencyHz = 50.0f;
    float rocofValue;

    while (1)
    {
        /* Wait for a new frequency from FrequencyTask */
        if (xQueueReceive(rocofQueue, &currentFrequencyHz, portMAX_DELAY) == pdTRUE)
        {
            if ((currentFrequencyHz + lastFrequencyHz) != 0.0f)
            {
                rocofValue =
                    (currentFrequencyHz - lastFrequencyHz) * 2.0f * currentFrequencyHz * lastFrequencyHz / (currentFrequencyHz + lastFrequencyHz);
            }
            else
            {
                rocofValue = 0.0f;
            }

            if (xSemaphoreTake(sharedStateMutex, portMAX_DELAY) == pdTRUE)
            {
                currentROCOF = rocofValue;
                xSemaphoreGive(sharedStateMutex);
            }

            lastFrequencyHz = currentFrequencyHz;
        }
    }
}
