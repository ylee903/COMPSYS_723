#include "FreeRTOS/FreeRTOS.h"
#include "FreeRTOS/task.h"
#include "FreeRTOS/semphr.h"
#include "shared_state.h"

#include "system.h"
#include "altera_avalon_pio_regs.h"

void SwitchPollTask(void *pvParameters)
{
    unsigned int switchValue;

    while (1)
    {
        switchValue = IORD_ALTERA_AVALON_PIO_DATA(SLIDE_SWITCH_BASE);
        switchValue &= 0x1F;

        if (xSemaphoreTake(sharedStateMutex, portMAX_DELAY) == pdTRUE)
        {
            userRequestedLoads = switchValue;
            xSemaphoreGive(sharedStateMutex);
        }

        vTaskDelay(pdMS_TO_TICKS(50));
    }
}
