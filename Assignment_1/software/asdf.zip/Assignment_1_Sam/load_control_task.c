#include "FreeRTOS/FreeRTOS.h"
#include "FreeRTOS/task.h"
#include "FreeRTOS/semphr.h"
#include "shared_state.h"

#include "system.h"
#include "altera_avalon_pio_regs.h"

void LoadControlTask(void *pvParameters)
{
    unsigned int requested;
    unsigned int shed;
    unsigned int maintenance;
    unsigned int actual;
    unsigned int redLeds;
    unsigned int greenLeds;

    while (1)
    {
        if (xSemaphoreTake(sharedStateMutex, portMAX_DELAY) == pdTRUE)
        {
        	requested = allowedLoads & 0x1F;
            shed = relayShedLoads & 0x1F;
            maintenance = maintenanceMode;

            if (maintenance)
            {
                actual = requested;
                greenLeds = 0;
            }
            else
            {
                actual = requested & (~shed);
                actual &= 0x1F;
                greenLeds = shed & 0x1F;
            }

            actualLoads = actual;
            redLeds = actual & 0x1F;

            xSemaphoreGive(sharedStateMutex);
        }

        IOWR_ALTERA_AVALON_PIO_DATA(RED_LEDS_BASE, redLeds);
        IOWR_ALTERA_AVALON_PIO_DATA(GREEN_LEDS_BASE, greenLeds);

        vTaskDelay(pdMS_TO_TICKS(50));
    }
}
